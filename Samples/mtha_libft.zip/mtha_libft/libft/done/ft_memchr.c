

#include <string.h>

void	*ft_memchr(const void *s, int c, size_t n)
{
	unsigned char		car;
	const unsigned char	*ptr;
	size_t				i;

	i = 0;
	car = (unsigned char)c;
	ptr = (const unsigned char*)s;
	if (!s)
		return (0);
	while (i < n)
	{
		if (*ptr == car)
			return ((void*)ptr);
		ptr++;
		i++;
	}
	return (NULL);
}
