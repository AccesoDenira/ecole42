

int	ft_isupper(int c)
{
	return (c >= 65 && c <= 90);
}
