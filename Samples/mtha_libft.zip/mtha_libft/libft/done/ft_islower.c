

int	ft_islower(int c)
{
	return (c >= 97 && c <= 122);
}
