

int		ft_isascii(int c)
{
	return ((unsigned)c <= 0177);
}
