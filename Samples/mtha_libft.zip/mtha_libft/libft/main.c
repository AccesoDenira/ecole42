#include <stdio.h>
#include <stdint.h>

int		main(void)
{
	printf("SIZE_MAX = [%u]\n", SIZE_MAX);
	return (0);
}
