void        ft_ft(int *nbr)
{
    *nbr = 42;
}
