#include <unistd.h>

void        ft_putchar(char c)
{
    write (1, &c, 1);
}

void       ft_putstr(char *str)
{
    while (*str)
    {
        ft_putchar(*str);
        str++;
    }
}

int     ft_strcmp(char *s1, char *s2)
{
    while (*s1 && *s2)
    {
        if (*s1 != *s2)
            return (*s1 - *s2);
        s1++;
        s2++;
    }
    return (*s1 - *s2);
}

void    ft_exchange(char **av, int index)
{
    char    *tmp;

    tmp = av[index];
    av[index] = av[index + 1];
    av[index + 1] = tmp;
}

int         main(int  ac, char **av)
{
    int     index;

    index = 0;
    if (ac > 2)
    {
        while (++index < ac - 1)
            if (ft_strcmp(av[index], av[index + 1]) > 0)
            {
                ft_exchange(av, index);
                index = 0;
            }
        index = 0;
        while (++index < ac)
        {
            ft_putstr(av[index]);
            ft_putchar('\n');
        }
    }
    return (0);
}
