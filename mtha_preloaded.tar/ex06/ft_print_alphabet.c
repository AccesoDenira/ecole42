#include <unistd.h>

void        ft_putchar(char c);

void        ft_print_alphabet(void)
{
    char        ltr;

    ltr = 'a';
    while (ltr <= 'z')
    {
        ft_putchar(ltr);
        ltr++;
    }
}
