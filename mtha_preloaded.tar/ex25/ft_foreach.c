void        ft_foreach(int *tab, int length, void(*f)(int))
{
    int     index;

    index = -1;
    if (tab)
        while (++index < lenght)
            f(tab[index]);
}
