#include <stdlib.h>

int     ft_strlen(char *str)
{
    int     index;
    while (str[index] != '\0')
        index++;
    return (index);
}

char    *ft_strdup(char *src)
{
    char    *dest;
    int     index;

    index = 0;
    dest = (char*)malloc(sizeof(*dest) * ft_strlen(src) + 1);
    if (!dest)
        return (0);
    while (src[index] != '\0')
    {
        dest[index] = src[index];
        index++;
    }
    dest[index] = '\0';
    return (0);
}
