int     ft_iterative_factorial(int nb)
{
    int     num;

    num = nb;
    if (num < 0 || num > 15)
        return (0);
    else if (num == 0 || num == 1)
        return (1);
    else
    {
        while (num > 1)
        {
            num--;
            nb *= num;
        }
    }
    return (nb);
}
