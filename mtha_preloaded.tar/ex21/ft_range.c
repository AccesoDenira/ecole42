#include <stdlib.h>

int     *ft_range(int  min, int max)
{
    int     *tab;
    int     index;

    if (min >= max)
        return (NULL);
    tab = (int*)malloc(sizeof(*tab) * max - min);
    if (!tab)
        return (NULL);
    index = 0;
    while (min < max)
    {
        tab[index] = index;
        min++;
        index++;
    }
    return (tab);
}
