#include "ft.h"
#define BUFFER_SIZE 4096

int         main(int ac, char  **av)
{
    int     fd;
    int     result;
    char    buf[BUFFER_SIZE + 1];

    if (ac == 1)
        write(1, "File name missing.\n", 19);
    if (ac >= 3)
        write(1, "Too many arguments.\n", 20);
    if (ac == 2)
    {
        fd = open(av[1], O_RDONLY);
        if (fd == -1)
            return (1);
        while ((result = read(fd, buf, BUFFER_SIZE)))
        {
            buf[result] = '\0';
            write(1, buf, result);
        }
        if (close(fd) == -1)
            return (1);
    }
    return (0);
}
