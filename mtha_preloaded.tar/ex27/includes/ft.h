#ifndef FT_H
# define FT_H
#include <unistd.h>
#include <fcntl.h>
#endif
