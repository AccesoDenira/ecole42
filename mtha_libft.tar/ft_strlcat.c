#include "libft.h"

static void     ft_strlcat_sub(char *d, const char *s, int  ava_space)
{
    while (*s != '\0')
    {
        if (ava_space != 1)
        {
            *d = *s;
            d++;
            ava_space--;
        }
        s++;
    }
    *d = '\0';
}

size_t      ft_strlcat(char *dest, char *src, size_t size)
{
    char        *d;
    char        *s;
    size_t      len;
    size_t      ava_space;

    d = dest;
    s = src;
    ava_space = size;
    while (ava_space && *d != '\0')
    {
        d++;
        ava_space--;
    }
    len = d - dest;
    ava_space = size - len;
    if (!ava_space)
        return (len + ft_strlen(src));
    ft_strlcat_sub(d, s, ava_space);
    return (len + ft_strlen(src));
}
