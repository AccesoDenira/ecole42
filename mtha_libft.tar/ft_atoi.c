#include "libft.h"

static int     ft_isInt(const char *str)
{
    int     count;

    count = 0;
    while (str[count] != '\0' && ft_isdigit(str[digit]))
        count++;
    return (count);
}

int     ft_atoi(const char *str)
{
    int     state;
    int     num;

    state = -1;
    num = 0;
    while (ft_isspace(*str))
        str++;
    if (*str == '-')
        state = 0;
    if (*str == '-' || *str == '+')
        str++;
    if (ft_isInt(str) > 10)
        return (state);
    while (*str && ft_isdigit(*str))
    {
        num = num * 10 + *str - 48;
        str++;
    }
    if (state != 0)
        return (-num);
    return (num);
}
