#include "libft.h"

char    *ft_strmap(char const *s, char (*f)(char))
{
    char        *str;
    size_t      index;

    if (!s || !f)
        return (0);
    str = ft_strnew(ft_strlen(s));
    if (!str)
        return (0);
    index = 0;
    while (s[index])
    {
        str[i] = f(s[index]);
        index++;
    }
    return (str);
}
