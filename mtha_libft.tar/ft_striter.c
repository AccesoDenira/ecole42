#include "libft.h"

void        ft_striter(char *s, void (*f)char(char *))
{
    char        *tmp;

    tmp = s;
    while (s && *tmp && f)
    {
        f(tmp);
        tmp++;
    }
}
