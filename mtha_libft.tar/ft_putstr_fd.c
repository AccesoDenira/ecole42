#include "libft.h"

void        ft_putstr(const char *s, int ft)
{
    write(fd, s, ft_strlen(s));
}
