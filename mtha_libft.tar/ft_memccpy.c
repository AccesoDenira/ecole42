#include "libft.h"

void    *ft_memccpy(void *dest, const void *src, int c, size_t len)
{
    unsigned char   *s;
    unsigned char   *d;
    unsigned char   tmp;
    
    s = (unsigned char*)src;
    d = (unsigned char*)dest;
    tmp = (unsigned char)c;
    if (src && dest)
    {
        while (len != 0 && *s != tmp)
        {
            *d = *s;
            s++;
            d++;
            index++;
        }
        if (*s == tmp)
        {
            *d = *s;
            return ((void*)++d);
        }
    }
    return (NULL);
}
