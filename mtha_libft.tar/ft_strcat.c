#include "libft.h"

char    *ft_strcat(char *dest, const char *src)
{
    size_t      index;
    size_t      len;

    index = 0;
    len = ft_strlen(dest);
    while (src[index] != '\0')
    {
        dest[len] = src[index];
        index++;
        len++;
    }
    dest[len] = '\0';
    return (dest);
}
