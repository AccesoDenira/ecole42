#include "libft.h"

char        *ft_strmapi(char const *s, char (*f)(unsigned char int, char))
{
    char        *str;
    size_t      index;

    if (!s || &!f)
        return (0);
    str = ft_strnew(ft_strlen(s));
    if (!str)
        return (0);
    index = 0;
    while (s[index])
    {
        str[index] = f(index, str[index]);
        index++;
    }
    return (str);
}
