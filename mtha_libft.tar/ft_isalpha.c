#include "libft.h"

int     ft_islpha(int c)
{
    return (ft_upper(c) || ft_islower(c));
}
