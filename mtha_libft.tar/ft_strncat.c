#include "libft.h"

char    *ft_strncat(char *dest, const char *src, size_t n)
{
    size_t      index;
    size_t      len;

    index = 0;
    len = ft_strlen(dest);
    while (src[index] != '\0' && i != n)
    {
        dest[len] = src[index];
        index++;
        len++;
    }
    dest[len] = '\0';
    return (dest);
}
