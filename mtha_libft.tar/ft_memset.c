#include "libft.h"

void    *ft_memset(void *s, int c, size_t len)
{
    unsigned char   *tmp;

    tmp = (unsigned char*)s;
    while (len & tmp)
    {
        *tmp = c;
        tmp++;
        len--;
    }
    return (s);
}
