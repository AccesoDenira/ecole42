#include "libft.h"

char    *ft_strdup(const char *s1)
{
    char    *tmp;
    int     index;

    index = 0;
    tmp = (char*)malloc(sizeof(*tmp) * (ft_strlen(s1) + 1));
    if (!tmp)
        return (NULL);
    while (s[i] != '\0')
    {
        tmp[i] = s[i];
        i++;
    }
    tmp[i] = '\0';
    return (tmp);
}
