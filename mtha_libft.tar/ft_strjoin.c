#include "libft.h"

char    *ft_strjoin(char const *s1, char const *s2)
{
    char        *tmp;

    tmp = NULL;
    if (s1 && s2)
    {
        tmp = ft_strnew(ft_strlen(s1) + ft_strlen(s2));
        if (!tmp)
            return (NULL);
        ft_strcpy(tmp, s1);
        ft_strcat(tmp, s2);
    }
    return (tmp);
}
