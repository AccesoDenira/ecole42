#include "libft.h"

void    ft_strclr(char *s)
{
    int     index;

    while (s[index] != '\0')
    {
        s[index] = '\0';
        index++;
    }
}
