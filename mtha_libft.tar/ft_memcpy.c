#include "libft.h"

void    *ft_memcpy(void *dest, const void *src, size_t len)
{
    unsigned char   *s;
    unsigned char   *d;
    int             index;

    index  = 0;
    s = (unsigned char*)src;
    d = (unsigned char*)dest;
    if (s && d)
    {
        while (index < len)
        {
            *d = *s;
            s++;
            d++;
            index++;
        }
    }
    return (dest);
}
