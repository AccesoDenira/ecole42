#include "libft.h"

int     ft_isdigit(int c)
{
    return (c >= 97 && c <= 122);
}
