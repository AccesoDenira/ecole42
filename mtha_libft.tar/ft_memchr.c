#include "libft.h"

void    *ft_memchr(const void *s, int c, size_t n)
{
    unsigned char       tmp;
    const unsigned char *src;
    size_t              index;

    index = 0;
    tmp = (unsigned char)c;
    src = (unsigned char*)s;
    if (!s)
        return (0);
    while (index < n)
    {
        if (*src == tmp)
            return ((void*)src);
        src++;
        index++;
    }
    return (NULL);
}
