#include "libft.h"

int     ft_isspace(int c)
{
    if (c == '\f' || c == '\t' || c == '\n' || c == '\r'
            || c == '\v || c == ' ')
        return (1);
    return (0);
}
